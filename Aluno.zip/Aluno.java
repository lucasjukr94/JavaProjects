public class Aluno extends Pessoa{
   private String Curso;
   private String Matricula;
   
   public Aluno(String Curso,String Matricula,String Nome,int Idade,String Identidade){
      this.Curso = Curso;
      this.Matricula = Matricula;
      this.Nome = Nome;
      this.Idade = Idade;
      this.Identidade = Identidade;
   }
   
   public void Imprime(){
      System.out.println("Curso:"+Curso);
      System.out.println("Matricula:"+Matricula);
      System.out.println("Nome:"+Nome);
      System.out.println("Idade:"+Idade);
      System.out.println("Identidade:"+Identidade);
   }
}