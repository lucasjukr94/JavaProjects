public class AtividadeHeranca{
   public static void main(String args[]){
      Aluno aluno = new Aluno("ADS","16200530","Lucas Ju",23,"543289612Y");
      aluno.Imprime();
   }
}