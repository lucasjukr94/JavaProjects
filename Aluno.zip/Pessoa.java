public abstract class Pessoa{
   protected String Nome;
   protected int Idade;
   protected String Identidade;
}