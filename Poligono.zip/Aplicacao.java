import java.util.Scanner;
public class Aplicacao{
   public static void main(String args[]){
      int opcao;
      Scanner input = new Scanner(System.in);
      
      double area;
      
      Poligono p;
      Quadrado q = new Quadrado(2);
      Retangulo r = new Retangulo(3,5);
      Triangulo t = new Triangulo(7,4);
      
      System.out.println("CALCULO DA AREA:");
      System.out.println("[1] - QUADRADO");
      System.out.println("[2] - RETANGULO");
      System.out.println("[3] - TRIANGULO");
      System.out.print("Escolha a op��o:");
      
      opcao = input.nextInt();
      
      p = null;
      switch(opcao){
         case 1: p=q;break;
         case 2: p=r;break;
         case 3: p=t;break;
         default:System.out.println("Opcao invalida!");
      }
      
      area = p.calcularArea();
      
      System.out.println("AREA = "+area);
      System.exit(0);
   }
}