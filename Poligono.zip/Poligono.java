public abstract class Poligono{
   private double area;
   
   public abstract double calcularArea();
}